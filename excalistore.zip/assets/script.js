const l=()=>console.log("Hello");l();
